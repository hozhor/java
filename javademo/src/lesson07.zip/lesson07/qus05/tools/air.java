package lesson07.qus05.tools;

public class air {
public static void main(String[] args) {
	number n =new number();
	n.number();
}
}
