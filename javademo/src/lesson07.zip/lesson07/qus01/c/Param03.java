package lesson07.qus01.c;
import lesson07.qus01.b.*;
public class Param03 extends Param {

	public static void main(String[] args) {
		//System.out.println(a);//private
		//System.out.println(b);//int
		System.out.println(c);//protected
	    System.out.println(d);//public

	}

}
