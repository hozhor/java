package lesson07.qus01.c;
import lesson07.qus01.b.*;
public class Param02 {

	public static void main(String[] args) {
		Param P = new Param();
		//System.out.println(P.a);//private		
		//System.out.println(P.b);//int
		//System.out.println(P.c);//protected
		System.out.println(P.d);//public		

	}

}
