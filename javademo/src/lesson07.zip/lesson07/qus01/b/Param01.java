package lesson07.qus01.b;

public class Param01 {

	public static void main(String[] args) {
		Param P = new Param();
		//System.out.println(P.a);//private		
		System.out.println(P.b);//int
		System.out.println(P.c);//protected
		System.out.println(P.d);//public
	}

}
