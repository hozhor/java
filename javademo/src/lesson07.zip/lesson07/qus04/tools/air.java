package lesson07.qus04.tools;
public class air {
public static void main(String[] args) {
	car m = new car();
	m.car();
	
}

}
